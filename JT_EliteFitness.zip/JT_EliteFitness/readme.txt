How to run the Profitness gym Project

1. Download the zip file

2. Extract the file and copy project folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name gym_db

6. Import gym_db.sql file (given inside the zip package in SQL file folder)

7.Run the script http://localhost/project2 (frontend)

Credential for admin panel :
email: admin@gmail.com
Password: 123456

Credential for gym member panel :
email: user@gmail.com
Password: user